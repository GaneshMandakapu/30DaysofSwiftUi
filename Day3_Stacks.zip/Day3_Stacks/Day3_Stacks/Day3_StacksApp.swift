//
//  Day3_StacksApp.swift
//  Day3_Stacks
//
//  Created by GaneshBalaraju on 25.05.24.
//

import SwiftUI

@main
struct Day3_StacksApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
