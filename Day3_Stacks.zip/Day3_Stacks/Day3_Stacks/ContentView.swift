//
//  ContentView.swift
//  Day3_Stacks
//
//  Created by GaneshBalaraju on 25.05.24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack(spacing: 20) {
            // ZStack for Profile Image with Camera Icon
            ZStack {
                Image(systemName: "person.circle.fill")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 150, height: 150)
                    .clipShape(Circle())
                    .shadow(radius: 10)
                
                Image(systemName: "camera.circle.fill")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 40, height: 40)
                    .offset(x: 50, y: 50)
                    .foregroundColor(.white)
            }
            .padding(.top, 50)
            
            // VStack for Name and Title
            VStack(alignment: .center) {
                Text("Ganesh Balaraju")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                
                Text("iOS Developer")
                    .fontDesign(.monospaced)
                    .font(.title2)
                    .foregroundColor(.gray)
            }
            
            // HStack for Contact Information
            HStack(spacing: 40) {
                VStack {
                    Image(systemName: "phone.fill")
                        .fontDesign(.rounded)
                        .font(.title)
                        .foregroundColor(.blue)
                    Text("+49 176438")
                        .font(.subheadline)
                }
                
                VStack {
                    Image(systemName: "envelope.fill")
                        .font(.title)
                        .foregroundColor(.blue)
                    Text("ganeshbalarajude@gmail.com")
                        .font(.subheadline)
                }
            }
            .padding(.horizontal, 40)
            
            Spacer()
        }
        .padding()
        .background(Color(UIColor.systemGroupedBackground))
        .edgesIgnoringSafeArea(.all)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
