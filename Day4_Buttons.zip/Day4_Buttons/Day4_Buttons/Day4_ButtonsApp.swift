//
//  Day4_ButtonsApp.swift
//  Day4_Buttons
//
//  Created by GaneshBalaraju on 26.05.24.
//

import SwiftUI

@main
struct Day4_ButtonsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
