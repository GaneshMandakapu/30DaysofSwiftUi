//
//  ContentView.swift
//  Day4_Buttons
//
//  Created by GaneshBalaraju on 26.05.24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack(spacing: 20) {
            Button(action: {
                print("Simple Button tapped")
            }) {
                Text("Simple Button")
            }

            Button(action: {
                print("Button with Image tapped")
            }) {
                HStack {
                    Image(systemName: "star")
                    Text("Button with Image")
                }
            }

            Button(action: {
                print("Custom Button tapped")
            }) {
                Text("Custom Button")
                    .padding()
                    .background(Color.pink)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }

            Button(action: {
                print("Styled Button tapped")
            }) {
                Text("Styled Button")
            }
            .buttonStyle(CustomButtonStyle())
        }
        .padding()
    }
}

struct CustomButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .padding()
            .background(configuration.isPressed ? Color.gray : Color.blue)
            .foregroundColor(.white)
            .cornerRadius(10)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

