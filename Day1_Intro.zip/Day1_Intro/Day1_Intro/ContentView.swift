//
//  ContentView.swift
//  Day1_Intro
//
//  Created by GaneshBalaraju on 23.05.24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Text("Hello, World!")
                .padding()
                .font(.largeTitle)
                .foregroundColor(.blue)
            
            Text("Welcome to SwiftUI Ganesh Balaraju")
                .background()
                .multilineTextAlignment(.leading)
                .padding(50)
                .font(.title)
                .foregroundColor(.green)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

