//
//  Day1_IntroApp.swift
//  Day1_Intro
//
//  Created by GaneshBalaraju on 23.05.24.
//

import SwiftUI

@main
struct Day1_IntroApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
