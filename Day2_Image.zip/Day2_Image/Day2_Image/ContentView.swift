//
//  ContentView.swift
//  Day2_Image
//
//  Created by GaneshBalaraju on 25.05.24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            // Profile Image
            Image("ganesh.jpg")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(width: 150, height: 150)
                .clipShape(Circle())
                .overlay(Circle().stroke(Color.white, lineWidth: 4))
                .shadow(radius: 10)
                .padding(.top, 50)

            // Name
            Text("Ganesh Balaraju")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding(.top, 20)
            
            // Bio
            Text("iOS Developer and Swift enthusiast. Passionate about building amazing applications and learning new technologies.")
                .font(.body)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding([.leading, .trailing], 40)
                .padding(.top, 10)

            Spacer()
        }
        .background(Color(UIColor.systemGroupedBackground))
        .edgesIgnoringSafeArea(.all)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

