//
//  Day2_ImageApp.swift
//  Day2_Image
//
//  Created by GaneshBalaraju on 25.05.24.
//

import SwiftUI

@main
struct Day2_ImageApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
