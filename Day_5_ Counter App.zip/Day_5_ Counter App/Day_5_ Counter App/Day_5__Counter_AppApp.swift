//
//  Day_5__Counter_AppApp.swift
//  Day_5_ Counter App
//
//  Created by GaneshBalaraju on 26.05.24.
//

import SwiftUI

@main
struct Day_5__Counter_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
