//
//  CounterView.swift
//  Day_5_ Counter App
//
//  Created by GaneshBalaraju on 26.05.24.
//

import SwiftUI

struct CounterView: View {
    @Binding var counter: Int

    var body: some View {
        VStack {
            Text("Counter: \(counter)")
                .font(.largeTitle)
                .padding()

            Button(action: {
                counter += 1
            }) {
                Text("Increment")
                    .padding()
                    .background(Color.green)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
        }
        .padding()
    }
}

struct CounterView_Previews: PreviewProvider {
    static var previews: some View {
        CounterView(counter: .constant(0))
    }
}

