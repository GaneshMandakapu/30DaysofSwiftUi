//
//  ContentView.swift
//  Day_5_ Counter App
//
//  Created by GaneshBalaraju on 26.05.24.
//

import SwiftUI

struct ContentView: View {
    @State private var counter: Int = 0

    var body: some View {
        VStack {
            CounterView(counter: $counter)
            
            Button(action: {
                counter = 0
            }) {
                Text("Reset")
                    .padding()
                    .background(Color.red)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}




