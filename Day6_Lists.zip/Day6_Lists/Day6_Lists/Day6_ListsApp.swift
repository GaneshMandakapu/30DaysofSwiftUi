//
//  Day6_ListsApp.swift
//  Day6_Lists
//
//  Created by GaneshBalaraju on 28.05.24.
//

import SwiftUI

@main
struct Day6_ListsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
