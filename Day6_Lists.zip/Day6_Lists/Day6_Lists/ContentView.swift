//
//  ContentView.swift
//  Day6_Lists
//
//  Created by GaneshBalaraju on 28.05.24.
//

import SwiftUI

struct ContentView: View {
    let items = ["Apple", "Banana", "Cherry", "Date", "Strawberry"]
    
    var body: some View {
        NavigationView {
            List {
                ForEach(items, id: \.self) { item in
                    NavigationLink(destination: DetailView(selectedItem: item)) {
                        HStack {
                            Image(systemName: "star.fill")
                                .foregroundColor(.yellow)
                            Text(item)
                                .font(.headline)
                                .padding()
                        }
                        .background(Color.gray.opacity(0.2))
                        .cornerRadius(8)
                        .shadow(radius: 2)
                    }
                    .listRowSeparator(.hidden)
                    .padding(.vertical, 5)
                }
            }
            .listStyle(InsetGroupedListStyle())
            .navigationTitle("Fruits")
        }
    }
}

struct DetailView: View {
    let selectedItem: String
    let details = ["Banana is yellow", "Apple is Red", "Cherry is Red", "Date is black", "Strawberry is Pink"]
    
    var body: some View {
        List {
            ForEach(details, id: \.self) { detail in
                HStack {
                    Image(systemName: "circle.empty")
                        .foregroundColor(.blue)
                    Text(detail)
                        .font(.subheadline)
                        .padding()
                }
                .background(Color.gray.opacity(0.2))
                .cornerRadius(8)
                .shadow(radius: 2)
            }
            .listRowSeparator(.hidden)
            .padding(.vertical, 5)
        }
        .listStyle(InsetGroupedListStyle())
        .navigationTitle(selectedItem)
    }
}
